//hosted
// const dbConfig = {
//     host: '97.74.91.11',
//     user: 'rrbeatlemeco_kahog',
//     password: 'kahog@123',
//     database: 'rrbeatlemeco_testkahog',
//   };
const dbConfig = {
  host: '103.110.127.141',
  user: 'beatlebuddy_kj_user',
  password: '%@?AuQl[.(9[',
  database: 'beatlebuddy_kj',
};
// local
// const dbConfig = {
//   host: 'localhost',
//   user: 'root',
//   password: '',
//   database: 'rrbeatlemeco_db',
// };

module.exports = dbConfig